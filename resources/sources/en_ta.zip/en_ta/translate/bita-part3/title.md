Biblical Imagery — Cultural Models
