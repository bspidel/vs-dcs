Connect — Sequential Time Relationship
