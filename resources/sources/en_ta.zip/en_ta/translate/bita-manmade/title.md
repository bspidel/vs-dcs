Biblical Imagery — Man-made Objects
