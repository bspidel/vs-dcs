Connect — Goal (Purpose) Relationship
