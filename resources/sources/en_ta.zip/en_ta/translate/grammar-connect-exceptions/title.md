Connect — Exception Clauses
