Biblical Imagery — Human Behavior
