Connect — Background Information
