Connect — Reason-and-Result Relationship
