Connect — Simultaneous Time Relationship
