Statements — Other Uses
