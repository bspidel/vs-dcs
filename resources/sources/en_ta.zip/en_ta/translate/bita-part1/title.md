Biblical Imagery — Common Patterns
