L’impératif - Autres utilisations
