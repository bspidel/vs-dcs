Comment savoir si le mot « vous » est singulier ?
