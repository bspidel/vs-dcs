Que puis-je faire si certaines informations explicites semblent ne pas être claires, pas naturelles ou pas nécessaires dans notre langue ?
