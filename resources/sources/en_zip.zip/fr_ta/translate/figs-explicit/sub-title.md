Comment puis-je être sûr que ma traduction communique les connaissances supposées et les informations implicites avec les informations explicites du message d’origine ?
