**unfoldingWord® Open Bible Stories**

**unrestricted visual Bible stories**

50 key stories of the Bible, from Creation to Revelation, in text, audio, and video, in any language, for free.

[https://openbiblestories.org](https://openbiblestories.org)

*Copyright © 2023 by unfoldingWord*

This work is made available under the Creative Commons Attribution-ShareAlike 4.0 International License (CC BY-SA). To view a copy of this license, visit [https://creativecommons.org/licenses/by-sa/4.0/](https://creativecommons.org/licenses/by-sa/4.0/) or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

unfoldingWord® is a registered trademark of unfoldingWord. Use of the unfoldingWord name or logo requires the written permission of unfoldingWord. Under the terms of the CC BY-SA license, you may copy and redistribute this unmodified work as long as you keep the unfoldingWord® trademark intact. However, if you modify a copy or translate this work, thereby creating a derivative work, you must remove the unfoldingWord® trademark.

On the derivative work, you must indicate what changes you have made and attribute the work as follows: “The original work by unfoldingWord is available from [https://openbiblestories.org](https://openbiblestories.org).” You must also make your derivative work available under the same license (CC BY-SA).

If you would like to notify unfoldingWord regarding your translation of this work, please contact us at [https://unfoldingword.org/contact/](https://unfoldingword.org/contact/).

Attribution of artwork: All images used in these stories are © Sweet Publishing ([www.sweetpublishing.com](https://sweetpublishing.com)) and are made available under a Creative Commons Attribution-Share Alike License ([https://creativecommons.org/licenses/by-sa/3.0](https://creativecommons.org/licenses/by-sa/3.0)).

Version 9, 2023-03-03

ISBN PDF: 978-1-62666-005-2 | ISBN Print: 978-1-62666-006-9

*To our brothers and sisters in Christ all over the world—the global church. It is our prayer that God would use this visual overview of His Word to bless, strengthen, and encourage you.*
