### Get Involved!

We want to make these unrestricted visual Bible stories available in _every language of the world_ and you can help! This is not impossible—we think it can happen if the whole body of Christ works together to translate and distribute this resource.

### Share Freely

Give as many copies of this book away as you want, without restriction. All digital versions are free online, and because of the open license we are using, you can even republish unfoldingWord® Open Bible Stories commercially anywhere in the world without paying royalties! Find out more at [openbiblestories.org](https://openbiblestories.org).

### Extend!

Get unfoldingWord® Open Bible Stories as videos and mobile phone applications in other languages at [openbiblestories.org](https://openbiblestories.org). On the website, you can also get help translating unfoldingWord® Open Bible Stories into _your_ language.
