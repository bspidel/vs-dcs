# License

Cet ouvrage est disponible sous la licence internationale "Creative Commons Attibution-ShareAlike 4.0

([http://creativecommons.org/licenses/by-sa/4.0/](http://creativecommons.org/licenses/by-sa/4.0/))

## Vous êtes libre:

  * **De partager** - de copier, et de redistribuer ce document sur tous médias et dans n'importe quel format
  * **D'adapter** - mélanger, transformer et ajouter d'autres choses à ce document quelque soit le but même commercial.

## Sous les conditions suivantes:

  * **Origine de l'ouvrage** - Vous devez attribuer l'ouvrage comme suit: "L'ouvrage d'origine est disponible à [Les mentions d'origine dans des oeuvres dérivées ne doivent en aucun cas laissé comprendre que nous approuvons ou que nous approuvons l'usage que vous en faites. ](http://openbiblestories.com.)

  * **ShareAlike** - Si vous re-mélangez, transformez, ou développez le document, vous devez diffuser vos contributions sous la même licence que celle de l'original.

Attribution du travail artistique: Toutes les images utilisées dans ces histoires sont de (Sweet Publishing.com) et sont disponibles sous la licence "Creative Commons Attibution-ShareAlike License ([http://creative](http://creative) commons.org/licenses/by-sa/3.0).
