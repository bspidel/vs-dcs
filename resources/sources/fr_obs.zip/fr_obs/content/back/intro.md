### Participez !

Nous voulons rendre le visuel de cette mini-bible disponible dans toutes les langues du monde et vous pouvez nous aider ! C’est possible - nous pensons que ceci pourrait être réalisé si tous les Croyants oeuvraient ensemble pour traduire et propager cette ressource.

### Partagez Librement

Donnez autant de copies de ce livre que vous voulez, sans restriction. Toutes les versions digitales sont disponibles gratuitement en ligne, et grâce à la licence libre que nous utilisons, vous pouvez même rééditer Open Bible Stories commercialement n’importe où dans le monde sans payer les droits d’auteurs ! Voir plus sur
http://openbiblestories.org.

### Complétez !

Procurez-vous Open Bible Stories au format vidéo ou en tant qu’application mobile dans d’autres langues sur http:/openbiblestories.org. Sur le site internet, vous pouvez aussi obtenir de l’aide pour traduire Open Bible Stories dans votre langue.
