**Histoires de la Bible Libres**

**Histoires bibliques visuelles avec accès libre**

50 histoires clés de la Bible, de la Création à la Révélation, en texte, en audio et en vidéo, dans toutes les langues, gratuitement.

Ce travail est disponible sous la licence internationale Creative Commons Attribution-ShareAlike 4.0. Pour voir une copie de cette licence, visitez http://creativecommons.org/licenses/by-sa/4.0/ ou envoyez une lettre à Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

Cette œuvre est une traduction des Histoires de la Bible Libre faite par unfoldingWord®. L’œuvre originale de unfoldingWord est disponible sur le site
[https://openbiblestories.org](https://openbiblestories.org).

Si vous souhaitez informer unfoldingWord de votre traduction de cette œuvre, veuillez nous contacter à l’adresse du site suivante : [https://unfoldingword.org/contact/](https://unfoldingword.org/contact/).

Attribution d’œuvres d’art: toutes les images utilisées dans ces histoires sont © Sweet Publishing ([www.sweetpublishing.com](http://www.sweetpublishing.com)) et sont disponibles sous une licence Creative Commons Attribution-Share Alike
([http://creativecommons.org/licenses/by-sa/3.0](http://creativecommons.org/licenses/by-sa/3.0)).

*À nos frères et sœurs en Christ partout dans le monde - l’église mondiale. Nous prions que Dieu utilise cette vue d’ensemble de sa Parole pour vous bénir, vous fortifier et vous encourager.*