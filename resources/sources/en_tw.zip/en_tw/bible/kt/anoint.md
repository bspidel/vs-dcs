# anoint, anointed, anointing

## Definition:

The term “anoint” means to rub or pour oil on a person or object. In biblical times, there were several reasons for anointing someone with oil. Often this was a [Symbolic Action](rc://en/ta/man/translate/translate-symaction), representing God empowering that person with the Holy Spirit for special service to him.

* In the Old Testament, priests, kings, and prophets were anointed with oil to set them apart for special service to God. 
* Objects such as altars or the tabernacle were also anointed with oil to show that they were to be used to worship and glorify God.
* In the New Testament, sick people were anointed with oil for their healing.
* Sometimes the oil was mixed with spices, giving it a sweet, perfumed smell.
* The New Testament records two times that Jesus was anointed with perfumed oil by a woman, as an act of worship. 
* People prepared dead bodies for burial by anointing them with perfumed oils and spices.
* In the New Testament, receiving the Holy Spirit is described as anointing.
* The titles “Messiah” (Hebrew) and “Christ” (Greek) mean “the Anointed (One).”
* Jesus the Messiah is the one who was chosen and anointed as a Prophet, High Priest, and King.

## Translation Suggestions:

* Depending on the context, the term “anoint” could be translated as “pour/put oil on” or “consecrate by pouring oil on” or “consecrate” or “appoint.”
* Depending on the context, to “be anointed” could be translated as “be consecrated with oil” or “be appointed” or “be consecrated” or “be given the Holy Spirit.”
* A phrase like “the anointed priest,” could be translated as “the priest who was consecrated with oil” or “the priest who was set apart by the pouring on of oil.”

(See also: [Christ](../kt/christ.md), [consecrate](../kt/consecrate.md), [high priest](../kt/highpriest.md), [King of the Jews](../kt/kingofthejews.md), [priest](../kt/priest.md), [prophet](../kt/prophet.md))

## Bible References:

* [1 John 2:20](rc://en/tn/help/1jn/02/20)
* [1 John 2:27](rc://en/tn/help/1jn/02/27)
* [2 Corinthians 1:21](rc://en/tn/help/2co/01/21)
* [1 Samuel 16:2-3](rc://en/tn/help/1sa/16/02)
* [Acts 4:27-28](rc://en/tn/help/act/04/27)
* [Amos 6:5-6](rc://en/tn/help/amo/06/05)
* [Exodus 29:5-7](rc://en/tn/help/exo/29/05)
* [James 5:13-15](rc://en/tn/help/jas/05/13)

## Word Data:

* Strong’s: H0047, H0430, H1101, H1878, H3323, H4397, H4398, H4473, H4886, H4888, H4899, H5480, H8136, G00320, G02180, G07430, G14720, G20250, G34620, G55450, G55480
