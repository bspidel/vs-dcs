# Adonijah

## Definition:

Adonijah was the fourth son of King David.

* Adonijah tried to take over as king of Israel after the deaths of his brothers Absalom and Amnon.
* God, however, had promised that David’s son Solomon would be king, so Adonijah’s plot was overthrown and Solomon was made king.
* When Adonijah tried a second time to make himself king, Solomon put him to death.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [David](../names/david.md), [Solomon](../names/solomon.md))

## Bible References:

## Word Data:

* Strong’s: H0138
