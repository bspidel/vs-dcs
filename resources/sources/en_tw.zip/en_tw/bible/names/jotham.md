# Jotham

## Definition:

In the Old Testament, there were three men with the name Jotham.

* One man named Jotham was the youngest son of Gideon. Jotham helped defeat his older brother Abimelech, who had killed all the rest of their brothers.
* Another man named Jotham was a king over Judah for sixteen years following the death of his father Uzziah (Azariah).
* Like his father, King Jotham obeyed God and was a good king.
* However, by not removing the places of idol worship he caused the people of Judah to later turn away from God again.
* Jotham is also one of the ancestors listed in the genealogy of Jesus Christ in the book of Matthew.

(See also: [Abimelech](../names/abimelech.md), [Ahaz](../names/ahaz.md), [Gideon](../names/gideon.md), [Uzziah](../names/uzziah.md))

## Bible References:

* [2 Chronicles 26:21](rc://en/tn/help/2ch/26/21)
* [2 Kings 15:5](rc://en/tn/help/2ki/15/05)
* [Isaiah 1:1](rc://en/tn/help/isa/01/1)
* [Judges 9:5-6](rc://en/tn/help/jdg/09/05)

## Word Data:

* Strong’s: H3147
