# Azariah

## Facts:

Azariah was the name of several men in the Old Testament.

* One Azariah is best known by his Babylonian name, Abednego. He was one of many Israelites from Judah who were captured by Nebuchadnezzar’s army and taken to live in Babylon. Azariah and his fellow Israelites Hananiah and Mishael refused to worship the Babylonian king, so he had them thrown into a blazing furnace as punishment. But God protected them and they were not harmed at all.
* Uzziah king of Judah was also known as “Azariah.”
* Another Azariah was an Old Testament high priest.
* In the time of the prophet Jeremiah, a man named Azariah wrongly urged the Israelites to disobey God by leaving their homeland.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Babylon](../names/babylon.md), [Daniel](../names/daniel.md), [Hananiah](../names/hananiah.md), [Mishael](../names/mishael.md), [Jeremiah](../names/jeremiah.md), [Uzziah](../names/uzziah.md))

## Bible References:

* [1 Chronicles 2:38](rc://en/tn/help/1ch/02/38)
* [1 Kings 4:2](rc://en/tn/help/1ki/04/02)
* [2 Chronicles 15:1](rc://en/tn/help/2ch/15/01)
* [Daniel 1:6-7](rc://en/tn/help/dan/01/06)
* [Jeremiah 43:2](rc://en/tn/help/jer/43/02)

## Word Data:

* Strong’s: H5838
