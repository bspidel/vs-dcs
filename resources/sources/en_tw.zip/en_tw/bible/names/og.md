# Og

## Facts:

Og is the name of a man who was an Amorite king who ruled over the land of Bashan.

* The Israelites conquered Og and his people and land.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Amorite](../names/amorite.md), [Bashan](../names/bashan.md))

## Bible References:


## Word Data:

* Strong’s:
