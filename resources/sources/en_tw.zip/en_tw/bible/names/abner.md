# Abner

## Definition:

Abner was a cousin of King Saul in the Old Testament.

* Abner was the chief commander of Saul’s army, and introduced young David to Saul after David killed Goliath the giant.
* After King Saul’s death, Abner appointed Saul’s son Ishbosheth as king in Israel, while David was appointed king in Judah.
* Later, Abner was treacherously killed by David’s chief commander, Joab.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

## Bible References:

* [1 Chronicles 26:26-28](rc://en/tn/help/1ch/26/26)
* [1 Kings 2:5-6](rc://en/tn/help/1ki/02/05)
* [1 Kings 2:32](rc://en/tn/help/1ki/02/32)
* [1 Samuel 17:55-56](rc://en/tn/help/1sa/17/55)
* [2 Samuel 3:22](rc://en/tn/help/2sa/03/22)

## Word Data:

* Strong’s: H0074
