# Bethuel

## Facts:

Bethuel was the son of Abraham’s brother Nahor.

* Bethuel was the father of Rebekah and Laban.
* There was also a town called Bethuel, which may have been located in southern Judah, not far from the town of Beersheba.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Beersheba](../names/beersheba.md), [Laban](../names/laban.md), [Nahor](../names/nahor.md), [Rebekah](../names/rebekah.md))

## Bible References:

* [1 Chronicles 4:30](rc://en/tn/help/1ch/04/30)
* [Genesis 28:2](rc://en/tn/help/gen/28/02)

## Word Data:

* Strong’s: H1328
