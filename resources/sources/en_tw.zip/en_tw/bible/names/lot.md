# Lot

## Facts:

Lot was Abraham’s nephew.

* He was the son of Abraham’s brother Haran.
* Lot traveled with Abraham to the land of Canaan and settled in the city of Sodom.
* Lot was the ancestor of the Moabites and Ammonites.
* When enemy kings attacked Sodom and captured Lot, Abraham came with several hundred men to rescue Lot and recover his belongings.
* The people living in the city of Sodom were very wicked, so God destroyed that city. But he first told Lot and his family to leave the city so that that they could escape.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Abraham](../names/abraham.md), [Ammon](../names/ammon.md), [Haran](../names/haran.md), [Moab](../names/moab.md), [Sodom](../names/sodom.md))

## Bible References:

* [2 Peter 2:8](rc://en/tn/help/2pe/02/08)
* [Genesis 11:27-28](rc://en/tn/help/gen/11/27)
* [Genesis 12:4-5](rc://en/tn/help/gen/12/04)

## Word Data:

* Strong’s: H3876, G30910
