# Heshbon

## Facts:

In Bible times, Heshbon was a major city of Moab. It was the capital city of king Sihon before the Israelites conquered it and began living in it.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Moab](../names/moab.md), [Sihon](../names/sihon.md))

## Bible References:


## Word Data:

* Strong’s: 
