# Herodias

## Facts:

Herodias was the wife of Herod Antipas in Judea during the time of John the Baptist.

* Herodias was originally the wife of Herod Antipas’s brother Philip, but later she unlawfully married Herod Antipas.
* John the Baptist rebuked Herod and Herodias for their unlawful marriage. Because of this, Herod put John in prison and because of Herodias eventually was beheaded.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Herod Antipas](../names/herodantipas.md), [John (the Baptist)](../names/johnthebaptist.md))

## Bible References:

* [Luke 3:19](rc://en/tn/help/luk/03/19)
* [Mark 6:17](rc://en/tn/help/mrk/06/17)
* [Mark 6:22](rc://en/tn/help/mrk/06/22)
* [Matthew 14:4](rc://en/tn/help/mat/14/04)

## Word Data:

* Strong’s: G22660
