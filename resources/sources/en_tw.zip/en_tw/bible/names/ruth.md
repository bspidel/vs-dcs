# Ruth

## Facts:

Ruth was a Moabite woman who lived during the time when judges were leading Israel. In Moab, she married an Israelite man named Mahlon after his family had moved there because of a famine in Israel. Mahlon died, and some time after that she left Moab with her mother-in-law Naomi to return to the city of Bethlehem in Israel.

* Ruth was loyal to Naomi and worked hard to provide food for her.
* She also committed herself to serving the one true God of Israel.
* Ruth married an Israelite man named Boaz and gave birth to a son named Obed. Obed became the grandfather of King David, and King David was an ancestor of Jesus.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Bethlehem](../names/bethlehem.md), [Boaz](../names/boaz.md), [David](../names/david.md), [judge](../other/judgeposition.md))

## Bible References:

* [Matthew 1:5](rc://en/tn/help/mat/01/05)
* [Ruth 1:3-5](rc://en/tn/help/rut/01/03)
* [Ruth 3:9](rc://en/tn/help/rut/03/09)
* [Ruth 4:6](rc://en/tn/help/rut/04/06)

## Word Data:

* Strong’s: H7327, G45030
