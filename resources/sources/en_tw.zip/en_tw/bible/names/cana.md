# Cana

## Definition:

Cana was a village or town in the province of Galilee, located about nine miles north of Nazareth.

* Cana was the hometown of Nathanael, one of the Twelve.
* Jesus attended a wedding feast in Cana and performed his first miracle there when he turned water into wine.
* Some time after that, Jesus came back to Cana and met an official there from Capernaum who requested healing for his son.

(See also: [Capernaum](../names/capernaum.md), [Galilee](../names/galilee.md), [the twelve](../kt/thetwelve.md))

## Bible References:

* [John 2:1-2](rc://en/tn/help/jhn/02/01)
* [John 4:46-47](rc://en/tn/help/jhn/04/46)

## Word Data:

* Strong’s: G25800
