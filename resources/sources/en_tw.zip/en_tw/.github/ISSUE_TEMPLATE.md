**Thank you so much for submitting a suggested change.**

We ask that you title the issue starting with the first set of words in the title of the translationWord. For example you will type in the Title field above:

    spirit of God

Will you please start your suggestion with a copy of the current text and then put 2 blank lines and then your suggested change below that.

For example:

    Abner was the chief commander of Saul’s army, (this is the text of the tW page)

    Abner was the** head leader** of Saul’s army (this is a suggested change - with the suggestion in bold)

**We really appreciate your help in making the resources the best they can be!**

(you can replace all of the above text with your suggestions)
